#include "dialog.h"
#include "ui_dialog.h"

Dialog::Dialog(QWidget *parent)
    : QDialog(parent)
    , ui(new Ui::Dialog)
{
    ui->setupUi(this);

    connect(ui->clearButton, &QPushButton::clicked, ui->textBrowser, &QTextBrowser::clear);

}

Dialog::~Dialog()
{
    delete ui;
}

void Dialog::dragEnterEvent(QDragEnterEvent *e)
{

    QDialog::dragEnterEvent(e);
}

void Dialog::dropEvent(QDropEvent *e)
{

    QDialog::dropEvent(e);
}
