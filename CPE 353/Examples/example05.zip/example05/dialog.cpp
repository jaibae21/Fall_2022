#include "dialog.h"
#include "ui_dialog.h"

Dialog::Dialog(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::Dialog)
{
    ui->setupUi(this);

    // Part 1
    timerID = QObject::startTimer(1000);

    // Part 2
    connect(ui->saveButton, &QPushButton::clicked, this, &Dialog::saveEditContents);
}

Dialog::~Dialog()
{
    delete ui;
}

bool Dialog::event(QEvent* e)
{
    // If the event pointer is NULL, exit normally

    // If the event is a timer event, then is the
    // event associated with the timer of interest?
    // If so, then perform the special event handling

    // Do whatever else is normally done for such an event
}

void Dialog::timerEvent(QTimerEvent *te)
{
    // If the timer event pointer is NULL, exit normally


    // If the timer event is for the event of interest
    // then perform the special event handling


    // Do whatever else is normally done for such an event
}

void Dialog::saveEditContents()
{
    qDebug() << "****************************************************";


    qDebug() << "Saving edit contents into 'stuff.txt' via QTextStream object now....";


    qDebug() << "Clearing lineEdit now....";


    qDebug() << "Echo file contents to console now....";

    qDebug() << "****************************************************";
}
