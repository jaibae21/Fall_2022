#ifndef DIALOG_H
#define DIALOG_H

#include <QDialog>
#include <QFile>
#include <QTextStream>
#include <QTimer>
#include <QtDebug>

namespace Ui {
class Dialog;
}

class Dialog : public QDialog
{
    Q_OBJECT

public:
    explicit Dialog(QWidget *parent = nullptr);
    ~Dialog();

protected:
    bool event(QEvent* e);
    void timerEvent(QTimerEvent* te);

private:
    Ui::Dialog *ui;
    int counter = 0;
    int timerID;

private slots:
    void saveEditContents();
};

#endif // DIALOG_H
