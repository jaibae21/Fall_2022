//
// Code Profiling
//

#include <iostream>
#include <vector>
#include <random>

#include "bubbleSort.h"
#include "insertionSort.h"
#include "selectionSort.h"
#include "mergeSort.h"
#include "quickSort.h"

const int MAX_NUM = 100;

using namespace std;

void printdata(vector<int> & values, int n)
{
    for(int k = 0; k < n; k++)
    {
        cout << values[k] << " ";
    }
    cout << endl;
}

void printbar() { cout << "##########################################################" << endl; }

int main(int argc, char* argv[])
{
    vector<int> data;
    for(int k = MAX_NUM - 1; k >= 0; k--)
    {
        data.push_back(k);
    }

    vector<int> copy1 = data;
    vector<int> copy2 = data;
    vector<int> copy3 = data;
    vector<int> copy4 = data;
    vector<int> copy5 = data;

    printbar();
    cout << "Bubble Sort" << endl;
//    printdata(copy1, MAX_NUM);
    bubbleSort(copy1, MAX_NUM);
//    printdata(copy1, MAX_NUM);

    printbar();
    cout << "Insertion Sort" << endl;
//    printdata(copy2, MAX_NUM);
    insertionSort(copy2, MAX_NUM);
//    printdata(copy2, MAX_NUM);

    printbar();
    cout << "Selection Sort" << endl;
//    printdata(copy3, MAX_NUM);
    selectionSort(copy3, MAX_NUM);
//    printdata(copy3, MAX_NUM);

    printbar();
    cout << "Merge Sort" << endl;
//    printdata(copy4, MAX_NUM);
    mergeSort(copy4, 0, MAX_NUM - 1);
//    printdata(copy4, MAX_NUM);

    printbar();
    cout << "Quicksort" << endl;
//    printdata(copy5, MAX_NUM);
    quickSort(copy5, 0, MAX_NUM - 1);
//    printdata(copy5, MAX_NUM);

    printbar();
    
    return 0;
}


